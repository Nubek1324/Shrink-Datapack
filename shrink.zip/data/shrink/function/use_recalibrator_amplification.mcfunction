attribute @s minecraft:scale base set 3.5
attribute @s minecraft:block_interaction_range base set 10
attribute @s minecraft:entity_interaction_range base set 10
attribute @s jump_strength base set 1.5
advancement revoke @s only shrink:use_recalibrator_amplification