attribute @s minecraft:scale base set 0
attribute @s minecraft:block_interaction_range base set 3
attribute @s minecraft:entity_interaction_range base set 3
attribute @s jump_strength base set 0.35
attribute @s minecraft:step_height base set 0
advancement revoke @s only shrink:use_recalibrator_reduction