attribute @s minecraft:scale base reset
attribute @s minecraft:block_interaction_range base reset
attribute @s minecraft:entity_interaction_range base reset
attribute @s jump_strength base reset
attribute @s minecraft:step_height base reset
advancement revoke @s only shrink:use_recalibrator_reset